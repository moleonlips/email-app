import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-static',
  templateUrl: './static.component.html',
  styleUrls: ['./static.component.css']
})
export class StaticComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  username = JSON.parse(localStorage.getItem('curUser')!)

  ngOnInit(): void { }

  logout() {
    localStorage.removeItem('curUser')
    localStorage.removeItem('isLoged')
    this.router.navigate([''])
  }

}

import { BreakLinePipe } from './break-line.pipe';

describe('BreakLinePipe', () => {
  it('create an instance', () => {
    const pipe = new BreakLinePipe();
    expect(pipe).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import MESS_DATA from '../../../assets/messages.json'
@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private route: Router) { }

  curFolder = new Subject<string>();

  messages: any = []

  folders = MESS_DATA
    .map(mess => mess.folder)
    .reduce((a: any, c) => {
      return (!a.includes(c) ? [...a, c] : [...a])
    }, []).sort()

  users = MESS_DATA
    .map(mess => mess.to)
    .reduce((a: any, c) => {
      return (!a.includes(c) ? [...a, c] : [...a])
    }, [])


  login(username: string, password: string) {
    if (username && password === 'password') {

      setTimeout(() => {
        this.route.navigate(['/myapp'])
      }, 0);

      localStorage.setItem('curUser', JSON.stringify(username))
      localStorage.setItem('isLoged', JSON.stringify(true))

      this.messages = MESS_DATA.filter(mess => mess.to === username)
      
    }
  }

  getMessages(folder: string, user: string) {
    setTimeout(() => {
      this.curFolder.next(folder)
    }, 1);
    return MESS_DATA.filter(mess => mess.folder === folder && mess.to === user)
  }

  getMessageDetails(id: string) {
    return MESS_DATA.filter(mess => mess._id === id)[0]
  }
}
